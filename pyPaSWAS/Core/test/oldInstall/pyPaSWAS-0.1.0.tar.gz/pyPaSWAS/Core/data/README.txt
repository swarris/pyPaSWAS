Folder contents:
----------------

* aaindex2.dat      Amino Acid substitution matrices available from: http://www.genome.jp/aaindex/
			        Each substitution matrix is identified by its ID which can be given on the
			        commandline with the --matrix=ID parameter. The dataset includes the following
			        substitution matrices: http://www.genome.jp/aaindex/AAindex/list_of_matrices
			        with the current version being 9.1. To update, please replace the file with
			        a newer version downloaded from the link above.
